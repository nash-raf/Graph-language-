from pathlib import Path
import sys,shutil,json,subprocess,os,statistics,re
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P));import series
header=r"""
#include <time.h>
static unsigned long long diag_ns[9],diag_calls[9],diag_modes[4],diag_active[257],diag_grants[257],diag_underfilled;
static unsigned long long diag_clock(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (unsigned long long)t.tv_sec*1000000000+t.tv_nsec;}
typedef struct{int id;unsigned long long begin;} DiagScope;
static void diag_end(DiagScope *p){diag_ns[p->id]+=diag_clock()-p->begin;++diag_calls[p->id];}
#define DIAG(ID) DiagScope diagnostic_scope __attribute__((cleanup(diag_end)))={ID,diag_clock()}
__attribute__((destructor)) static void diag_report(void){const char *p=getenv("SGPL_PROFILE_JSON");if(!p)return;FILE *f=fopen(p,"w");if(!f)return;fprintf(f,"{\"phases\":[");const char *names[]={"begin","finish","compaction","dispatch","records","weight_indices","count","fill","view_cache"};for(int i=0;i<9;++i)fprintf(f,"%s{\"name\":\"%s\",\"calls\":%llu,\"ms\":%.6f}",i?",":"",names[i],diag_calls[i],diag_ns[i]/1e6);fprintf(f,"],\"record_modes\":[%llu,%llu,%llu],\"underfilled_rounds\":%llu,\"active_partitions\":[",diag_modes[0],diag_modes[1],diag_modes[2],diag_underfilled);for(int i=0;i<=256;++i)fprintf(f,"%s%llu",i?",":"",diag_active[i]);fprintf(f,"],\"granted_workers\":[");for(int i=0;i<=256;++i)fprintf(f,"%s%llu",i?",":"",diag_grants[i]);fprintf(f,"]}\n");fclose(f);}
"""
summary=[]
for stage in ['00_baseline','03_view_dispatch_versioning']:
 original=P/stage;W=P/'profiles_final'/stage;W.mkdir(exist_ok=True)
 for f in original.iterdir():
  if f.suffix in ['.c','.h','.inc']:shutil.copy2(f,W/f.name)
 (W/'diag.h').write_text(header)
 t=(W/'autotuner_runtime.c').read_text();at=t.index('/* Forward declaring external Roaring C API');t=t[:at]+'#include "diag.h"\n'+t[at:]
 for function,id in [('sgpl_exec_step_dispatch_body',3),('sgpl_exec_spatial_begin',0),('sgpl_exec_spatial_finish',1)]:
  pattern=re.compile(r'((?:static void|int32_t) '+function+r'\([^;]*?\)\s*\{)')
  t,n=pattern.subn(lambda m:m.group(1)+' DIAG('+str(id)+');',t,count=1);assert n==1,function
 needle='    int pool_rc=sgpl_run_on_worker_pool('
 assert needle in t
 t=t.replace(needle,'    if(job.count<=256)++diag_active[job.count]; if(worker_budget<=256)++diag_grants[worker_budget]; if(job.count<worker_budget)++diag_underfilled;\n'+needle)
 (W/'autotuner_runtime.c').write_text(t)
 t=(W/'array_frontier_runtime.inc').read_text()
 for function,id in [('sgpl_array_weight_indices',5),('sgpl_array_records',4),('sgpl_array_compact',2)]:
  pattern=re.compile(r'('+function+r'\([^;]*?\)\s*\{)');t,n=pattern.subn(lambda m:m.group(1)+' DIAG('+str(id)+');',t,count=1);assert n==1
 (W/'array_frontier_runtime.inc').write_text(t)
 if (W/'array_segment_runtime.inc').exists():
  t=(W/'array_segment_runtime.inc').read_text()
  t,n=re.subn(r'(sgpl_segment_view\([^;]*?\)\s*\{)',lambda m:m.group(1)+' DIAG(8);',t,count=1);assert n==1
  (W/'array_segment_runtime.inc').write_text(t)
 t=(W/'array_preparation_runtime.inc').read_text()
 for id,pattern in [(6,r'(  sgpl_run_preparation\(sgpl_array_count_chunks,&job,width\);)'),(7,r'(  sgpl_run_preparation\([^;]*?sgpl_array_fill_chunks[^;]*?;)')]:
  t,n=re.subn(pattern,lambda m:'{ DIAG('+str(id)+'); '+m.group(1)+' }',t,count=1);assert n==1,id
 t=t.replace('  c->gpu_record_count=records;', '  ++diag_modes[c->array_compact_records]; c->gpu_record_count=records;')
 (W/'array_preparation_runtime.inc').write_text(t)
 with (W/'build.log').open('w') as log:subprocess.run(['gcc','-O3','-fopenmp','-pthread','-c','autotuner_runtime.c','-o','diagnostic.o'],cwd=W,stdout=log,stderr=subprocess.STDOUT,check=True)
 for alg,needle in [('sssp','DSJC1000-5'),('sssp','slashdot')]:
  c=next(c for c in series.plan if c['algorithm']==alg and needle in c['row']['graph']);d=series.bench.case_dir(original/'cases',alg,c['row']);exe=W/(alg+'_'+needle)
  subprocess.run(['g++','-O3','-fopenmp','-no-pie',str(d/'timed.o')]+[str(W/'diagnostic.o') if x=='autotuner_runtime.o' else str(original/x) for x in series.bench.OBJECTS]+['-Wl,--wrap=timer_runtime','-ldl','-lnlopt','-o',str(exe)],cwd=W,check=True)
  profiles=[]
  for i in range(3):
   env=series.bench.clean_env('p1',32);report=W/(alg+'_'+needle+'_'+str(i)+'.json');env['SGPL_PROFILE_JSON']=str(report)
   rec=series.launcher.run([str(exe)],d,env,W/(alg+'_'+needle+'_'+str(i)+'.log'),600,W/(alg+'_'+needle+'_'+str(i)+'.stamp'))
   assert rec['exit_code']==0;profiles.append(json.loads(report.read_text()))
  phases={x['name']:statistics.median(p['phases'][idx]['ms'] for p in profiles) for idx,x in enumerate(profiles[0]['phases'])}
  item={'stage':stage,'algorithm':alg,'graph':c['row']['graph'],'median_diagnostic_phases_ms':phases,'record_modes':profiles[0]['record_modes'],'underfilled_rounds':profiles[0]['underfilled_rounds'],'active_partition_histogram':{str(i):n for i,n in enumerate(profiles[0]['active_partitions']) if n},'granted_worker_histogram':{str(i):n for i,n in enumerate(profiles[0]['granted_workers']) if n}}
  summary.append(item);print(json.dumps(item),flush=True)
(P/'profiles_final/phase_summary.json').write_text(json.dumps(summary,indent=2))
