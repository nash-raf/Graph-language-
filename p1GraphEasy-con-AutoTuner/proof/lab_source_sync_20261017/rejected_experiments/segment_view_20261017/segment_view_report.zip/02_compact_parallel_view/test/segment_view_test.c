#define SGPL_SPATIAL_FIXTURE_ONLY
#include "spatial_exec_test.c"
static atomic_int pair_calls,weight_errors;
static int occurrence_group;
int32_t graph_get_edge_weight(void *opaque,int32_t u,int32_t v) {
  ExecTestGraph *g=opaque;if(u<0||u>=g->n)return INT32_MAX;
  for(int64_t e=g->row_ptr[u];e<g->row_ptr[u+1];++e)if(g->col_idx[e]==v)return g->weights?g->weights[e]:1;
  return INT32_MAX;
}
static void segment_pair(void *state,sgpl_exec_ctx *c,int32_t u,int32_t v) {
  (void)state;atomic_fetch_add(&pair_calls,1);
  if(autograph_exec_ctx_edge_weight(c,c->graph,u,v)!=graph_get_edge_weight(c->graph,u,v))atomic_fetch_add(&weight_errors,1);
  if(sgpl_current_thread_budget()>1)atomic_fetch_add(&weight_errors,1);
  autograph_frontier_activate(c,v);autograph_frontier_activate(c,v);
}
static sgpl_exec_ctx *make(ExecTestGraph *g,int32_t *input,int size,int proof,int source,int32_t **out,int64_t *cap,int32_t *head) {
  check(autograph_build_array_cut(g,3)==3,"array partition ranges");
  sgpl_runtime_op *op=autograph_exec_op_create(SGPL_OP_PAIR|(proof?SGPL_OP_SEGMENT_VIEW:0),NULL,segment_pair,NULL,NULL,NULL,NULL,NULL,0),*ops[]={op};
  sgpl_exec_ctx *c=autograph_exec_ctx_create(g,source?SGPL_TRAVERSE_OWNER_U:SGPL_TRAVERSE_OWNER_V,SGPL_DOMAIN_FRONTIER,NULL,NULL,NULL,0,head,NULL,0,ops,1,-1);
  check(!autograph_exec_ctx_bind_array_frontier(c,input,size,out,cap,2),"bind occurrence array");
  int group=source?SGPL_SPATIAL_SOURCE:SGPL_SPATIAL_DESTINATION;
  check(!autograph_exec_ctx_prepare_spatial(c,occurrence_group?SGPL_SPATIAL_PAIR_OCCURRENCE:group,group,1),"prepare certified/fallback context");
  autograph_exec_ctx_set_dag_axes(c,1,-1);return c;
}
static void execute_check(sgpl_exec_ctx *c,int32_t **out,const int32_t *expected,int count) {
  atomic_store(&pair_calls,0);atomic_store(&weight_errors,0);
  check(autograph_frontier_execute(c->graph,c)==count,"full append cardinality");
  check(atomic_load(&pair_calls)==count/2&&!atomic_load(&weight_errors),"pair callbacks, first-match weights and nested budget");
  check(!memcmp(*out,expected,(size_t)count*4),"source/neighbor order and duplicate occurrences");
  check(c->spatial_occupied_groups==(c->spatial_group==SGPL_SPATIAL_PAIR_OCCURRENCE?count/2:(c->spatial_group==SGPL_SPATIAL_SOURCE?6:24)),"exact occupied endpoint count");
  check(!sgpl_debug_reserved_threads(),"budget ledger released");
}
int main(void) {
  enum {N=24,D=48,M=N*D,F=7,O=F*D*2};
  int64_t rows[N+1];int32_t cols[M],weights[M],input[F]={4,1,3,0,1,23,2},expected[O];
  for(int u=0;u<N;++u){rows[u]=u*D;for(int e=0;e<D;++e){cols[u*D+e]=(e*7)%N;weights[u*D+e]=1000*u+e+1;}}rows[N]=M;
  for(int i=0;i<F;++i)for(int e=0;e<D;++e)expected[2*(i*D+e)]=expected[2*(i*D+e)+1]=cols[input[i]*D+e];
  ExecTestGraph g={.n=N,.m=M,.row_ptr=rows,.col_idx=cols,.weights=weights,.directed=1};autograph_init(&g,N,M,NULL,NULL,NULL);
  for(int source=0;source<2;++source) {
    int32_t *out=NULL,head=0;int64_t cap=0;sgpl_exec_ctx *c=make(&g,input,F,0,source,&out,&cap,&head);
    check(c->array_compact_records==2,"no certificate retains materialized format");execute_check(c,&out,expected,O);autograph_exec_ctx_destroy(c);sgpl_frontier_release_buffers();
  }
  int32_t *out=NULL,head=0;int64_t cap=0;sgpl_exec_ctx *c=make(&g,input,F,1,0,&out,&cap,&head);
  check(c->array_compact_records==3&&c->gpu_record_count==F*3&&c->array_work_count==F*D,"descriptors replace per-edge records");execute_check(c,&out,expected,O);
  /* Another graph replaces the thread cache while the first view is live. */
  ExecTestGraph other=g;autograph_init(&other,N,M,NULL,NULL,NULL);int32_t *out2=NULL,head2=0;int64_t cap2=0;
  sgpl_exec_ctx *c2=make(&other,input,F,1,0,&out2,&cap2,&head2);execute_check(c2,&out2,expected,O);
  autograph_exec_ctx_destroy(c2);execute_check(c,&out,expected,O);
  atomic_store(&fail_malloc,1);check(sgpl_gpu_prepare_spatial_records(c)==SGPL_DAG_ERR_NOMEM&&c->array_compact_records==3,"failed expansion preserves deferred view");execute_check(c,&out,expected,O);
  check(!sgpl_gpu_prepare_spatial_records(c)&&c->array_compact_records==0,"device upgrade expands transactionally");execute_check(c,&out,expected,O);
  autograph_exec_ctx_destroy(c);sgpl_frontier_release_buffers();
  cols[D]=2;autograph_record_adjacency_state(&g,N,M,rows,cols);
  for(int i=0;i<F;++i)for(int e=0;e<D;++e)expected[2*(i*D+e)]=expected[2*(i*D+e)+1]=cols[input[i]*D+e];
  out=NULL;cap=0;head=0;c=make(&g,input,F,1,0,&out,&cap,&head);check(c->array_compact_records==3,"publication rebuilds cached topology view");execute_check(c,&out,expected,O);
  autograph_exec_ctx_destroy(c);sgpl_frontier_release_buffers();
  occurrence_group=1;out=NULL;cap=0;head=0;c=make(&g,input,F,1,0,&out,&cap,&head);
  check(c->array_compact_records==3,"occurrence grouping uses deferred descriptors");execute_check(c,&out,expected,O);
  c->array_append_sites=1;
  check(autograph_frontier_execute(&g,c)<0&&!sgpl_debug_reserved_threads(),"per-pair append failure cancels and joins the team");
  autograph_exec_ctx_destroy(c);sgpl_frontier_release_buffers();
  printf("segmented records: %d failures\n",failures);return failures?1:0;
}
