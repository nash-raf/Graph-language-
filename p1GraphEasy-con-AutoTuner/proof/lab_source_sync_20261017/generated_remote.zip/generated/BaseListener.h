
// Generated from Base.g4 by ANTLR 4.13.1

#pragma once


#include "antlr4-runtime.h"
#include "BaseParser.h"


/**
 * This interface defines an abstract listener for a parse tree produced by BaseParser.
 */
class  BaseListener : public antlr4::tree::ParseTreeListener {
public:

  virtual void enterProgram(BaseParser::ProgramContext *ctx) = 0;
  virtual void exitProgram(BaseParser::ProgramContext *ctx) = 0;

  virtual void enterStatement(BaseParser::StatementContext *ctx) = 0;
  virtual void exitStatement(BaseParser::StatementContext *ctx) = 0;

  virtual void enterSwapStatement(BaseParser::SwapStatementContext *ctx) = 0;
  virtual void exitSwapStatement(BaseParser::SwapStatementContext *ctx) = 0;

  virtual void enterWeightedGraphDef(BaseParser::WeightedGraphDefContext *ctx) = 0;
  virtual void exitWeightedGraphDef(BaseParser::WeightedGraphDefContext *ctx) = 0;

  virtual void enterUnweightedGraphDef(BaseParser::UnweightedGraphDefContext *ctx) = 0;
  virtual void exitUnweightedGraphDef(BaseParser::UnweightedGraphDefContext *ctx) = 0;

  virtual void enterPlainGraphDef(BaseParser::PlainGraphDefContext *ctx) = 0;
  virtual void exitPlainGraphDef(BaseParser::PlainGraphDefContext *ctx) = 0;

  virtual void enterLoadGraphDef(BaseParser::LoadGraphDefContext *ctx) = 0;
  virtual void exitLoadGraphDef(BaseParser::LoadGraphDefContext *ctx) = 0;

  virtual void enterGraphProperty(BaseParser::GraphPropertyContext *ctx) = 0;
  virtual void exitGraphProperty(BaseParser::GraphPropertyContext *ctx) = 0;

  virtual void enterNodes(BaseParser::NodesContext *ctx) = 0;
  virtual void exitNodes(BaseParser::NodesContext *ctx) = 0;

  virtual void enterEdges(BaseParser::EdgesContext *ctx) = 0;
  virtual void exitEdges(BaseParser::EdgesContext *ctx) = 0;

  virtual void enterNodeList(BaseParser::NodeListContext *ctx) = 0;
  virtual void exitNodeList(BaseParser::NodeListContext *ctx) = 0;

  virtual void enterEdgeList(BaseParser::EdgeListContext *ctx) = 0;
  virtual void exitEdgeList(BaseParser::EdgeListContext *ctx) = 0;

  virtual void enterGraphID(BaseParser::GraphIDContext *ctx) = 0;
  virtual void exitGraphID(BaseParser::GraphIDContext *ctx) = 0;

  virtual void enterNodeID(BaseParser::NodeIDContext *ctx) = 0;
  virtual void exitNodeID(BaseParser::NodeIDContext *ctx) = 0;

  virtual void enterFileEdgeList(BaseParser::FileEdgeListContext *ctx) = 0;
  virtual void exitFileEdgeList(BaseParser::FileEdgeListContext *ctx) = 0;

  virtual void enterEdge(BaseParser::EdgeContext *ctx) = 0;
  virtual void exitEdge(BaseParser::EdgeContext *ctx) = 0;

  virtual void enterSimpleDeclaration(BaseParser::SimpleDeclarationContext *ctx) = 0;
  virtual void exitSimpleDeclaration(BaseParser::SimpleDeclarationContext *ctx) = 0;

  virtual void enterArrayDeclaration(BaseParser::ArrayDeclarationContext *ctx) = 0;
  virtual void exitArrayDeclaration(BaseParser::ArrayDeclarationContext *ctx) = 0;

  virtual void enterSetDecl(BaseParser::SetDeclContext *ctx) = 0;
  virtual void exitSetDecl(BaseParser::SetDeclContext *ctx) = 0;

  virtual void enterSetInitializer(BaseParser::SetInitializerContext *ctx) = 0;
  virtual void exitSetInitializer(BaseParser::SetInitializerContext *ctx) = 0;

  virtual void enterSetOperation(BaseParser::SetOperationContext *ctx) = 0;
  virtual void exitSetOperation(BaseParser::SetOperationContext *ctx) = 0;

  virtual void enterSetTarget(BaseParser::SetTargetContext *ctx) = 0;
  virtual void exitSetTarget(BaseParser::SetTargetContext *ctx) = 0;

  virtual void enterSetUnion(BaseParser::SetUnionContext *ctx) = 0;
  virtual void exitSetUnion(BaseParser::SetUnionContext *ctx) = 0;

  virtual void enterGraphEdgesSet(BaseParser::GraphEdgesSetContext *ctx) = 0;
  virtual void exitGraphEdgesSet(BaseParser::GraphEdgesSetContext *ctx) = 0;

  virtual void enterSetIntersect(BaseParser::SetIntersectContext *ctx) = 0;
  virtual void exitSetIntersect(BaseParser::SetIntersectContext *ctx) = 0;

  virtual void enterSetId(BaseParser::SetIdContext *ctx) = 0;
  virtual void exitSetId(BaseParser::SetIdContext *ctx) = 0;

  virtual void enterSetLiteral(BaseParser::SetLiteralContext *ctx) = 0;
  virtual void exitSetLiteral(BaseParser::SetLiteralContext *ctx) = 0;

  virtual void enterParenSet(BaseParser::ParenSetContext *ctx) = 0;
  virtual void exitParenSet(BaseParser::ParenSetContext *ctx) = 0;

  virtual void enterGraphNodesSet(BaseParser::GraphNodesSetContext *ctx) = 0;
  virtual void exitGraphNodesSet(BaseParser::GraphNodesSetContext *ctx) = 0;

  virtual void enterSetAddMethod(BaseParser::SetAddMethodContext *ctx) = 0;
  virtual void exitSetAddMethod(BaseParser::SetAddMethodContext *ctx) = 0;

  virtual void enterSetRemoveMethod(BaseParser::SetRemoveMethodContext *ctx) = 0;
  virtual void exitSetRemoveMethod(BaseParser::SetRemoveMethodContext *ctx) = 0;

  virtual void enterConditionalStatement(BaseParser::ConditionalStatementContext *ctx) = 0;
  virtual void exitConditionalStatement(BaseParser::ConditionalStatementContext *ctx) = 0;

  virtual void enterExprCondition(BaseParser::ExprConditionContext *ctx) = 0;
  virtual void exitExprCondition(BaseParser::ExprConditionContext *ctx) = 0;

  virtual void enterNodeCheck(BaseParser::NodeCheckContext *ctx) = 0;
  virtual void exitNodeCheck(BaseParser::NodeCheckContext *ctx) = 0;

  virtual void enterHasEdgeCall(BaseParser::HasEdgeCallContext *ctx) = 0;
  virtual void exitHasEdgeCall(BaseParser::HasEdgeCallContext *ctx) = 0;

  virtual void enterLogicalAnd(BaseParser::LogicalAndContext *ctx) = 0;
  virtual void exitLogicalAnd(BaseParser::LogicalAndContext *ctx) = 0;

  virtual void enterRelational(BaseParser::RelationalContext *ctx) = 0;
  virtual void exitRelational(BaseParser::RelationalContext *ctx) = 0;

  virtual void enterEdgeCheck(BaseParser::EdgeCheckContext *ctx) = 0;
  virtual void exitEdgeCheck(BaseParser::EdgeCheckContext *ctx) = 0;

  virtual void enterHasNodeCheck(BaseParser::HasNodeCheckContext *ctx) = 0;
  virtual void exitHasNodeCheck(BaseParser::HasNodeCheckContext *ctx) = 0;

  virtual void enterHasNodeCall(BaseParser::HasNodeCallContext *ctx) = 0;
  virtual void exitHasNodeCall(BaseParser::HasNodeCallContext *ctx) = 0;

  virtual void enterHasEdgeCheck(BaseParser::HasEdgeCheckContext *ctx) = 0;
  virtual void exitHasEdgeCheck(BaseParser::HasEdgeCheckContext *ctx) = 0;

  virtual void enterLogicalOr(BaseParser::LogicalOrContext *ctx) = 0;
  virtual void exitLogicalOr(BaseParser::LogicalOrContext *ctx) = 0;

  virtual void enterGraphComprehension(BaseParser::GraphComprehensionContext *ctx) = 0;
  virtual void exitGraphComprehension(BaseParser::GraphComprehensionContext *ctx) = 0;

  virtual void enterGraphExpr(BaseParser::GraphExprContext *ctx) = 0;
  virtual void exitGraphExpr(BaseParser::GraphExprContext *ctx) = 0;

  virtual void enterMotifMatchesDecl(BaseParser::MotifMatchesDeclContext *ctx) = 0;
  virtual void exitMotifMatchesDecl(BaseParser::MotifMatchesDeclContext *ctx) = 0;

  virtual void enterGraphListDecl(BaseParser::GraphListDeclContext *ctx) = 0;
  virtual void exitGraphListDecl(BaseParser::GraphListDeclContext *ctx) = 0;

  virtual void enterMotifSearchDecl(BaseParser::MotifSearchDeclContext *ctx) = 0;
  virtual void exitMotifSearchDecl(BaseParser::MotifSearchDeclContext *ctx) = 0;

  virtual void enterMotifEdge(BaseParser::MotifEdgeContext *ctx) = 0;
  virtual void exitMotifEdge(BaseParser::MotifEdgeContext *ctx) = 0;

  virtual void enterGraphLogicalAnd(BaseParser::GraphLogicalAndContext *ctx) = 0;
  virtual void exitGraphLogicalAnd(BaseParser::GraphLogicalAndContext *ctx) = 0;

  virtual void enterDegreeCondition(BaseParser::DegreeConditionContext *ctx) = 0;
  virtual void exitDegreeCondition(BaseParser::DegreeConditionContext *ctx) = 0;

  virtual void enterCycleCondition(BaseParser::CycleConditionContext *ctx) = 0;
  virtual void exitCycleCondition(BaseParser::CycleConditionContext *ctx) = 0;

  virtual void enterConnectedCondition(BaseParser::ConnectedConditionContext *ctx) = 0;
  virtual void exitConnectedCondition(BaseParser::ConnectedConditionContext *ctx) = 0;

  virtual void enterMotifCondition(BaseParser::MotifConditionContext *ctx) = 0;
  virtual void exitMotifCondition(BaseParser::MotifConditionContext *ctx) = 0;

  virtual void enterGraphLogicalOr(BaseParser::GraphLogicalOrContext *ctx) = 0;
  virtual void exitGraphLogicalOr(BaseParser::GraphLogicalOrContext *ctx) = 0;

  virtual void enterParenGraphCondition(BaseParser::ParenGraphConditionContext *ctx) = 0;
  virtual void exitParenGraphCondition(BaseParser::ParenGraphConditionContext *ctx) = 0;

  virtual void enterLoopStatement(BaseParser::LoopStatementContext *ctx) = 0;
  virtual void exitLoopStatement(BaseParser::LoopStatementContext *ctx) = 0;

  virtual void enterForeachStatement(BaseParser::ForeachStatementContext *ctx) = 0;
  virtual void exitForeachStatement(BaseParser::ForeachStatementContext *ctx) = 0;

  virtual void enterForeachNodes(BaseParser::ForeachNodesContext *ctx) = 0;
  virtual void exitForeachNodes(BaseParser::ForeachNodesContext *ctx) = 0;

  virtual void enterForeachEdges(BaseParser::ForeachEdgesContext *ctx) = 0;
  virtual void exitForeachEdges(BaseParser::ForeachEdgesContext *ctx) = 0;

  virtual void enterForeachNeighbors(BaseParser::ForeachNeighborsContext *ctx) = 0;
  virtual void exitForeachNeighbors(BaseParser::ForeachNeighborsContext *ctx) = 0;

  virtual void enterForEachElement(BaseParser::ForEachElementContext *ctx) = 0;
  virtual void exitForEachElement(BaseParser::ForEachElementContext *ctx) = 0;

  virtual void enterForEachGraph(BaseParser::ForEachGraphContext *ctx) = 0;
  virtual void exitForEachGraph(BaseParser::ForEachGraphContext *ctx) = 0;

  virtual void enterForEachMotif(BaseParser::ForEachMotifContext *ctx) = 0;
  virtual void exitForEachMotif(BaseParser::ForEachMotifContext *ctx) = 0;

  virtual void enterForEachPlain(BaseParser::ForEachPlainContext *ctx) = 0;
  virtual void exitForEachPlain(BaseParser::ForEachPlainContext *ctx) = 0;

  virtual void enterWhileStatement(BaseParser::WhileStatementContext *ctx) = 0;
  virtual void exitWhileStatement(BaseParser::WhileStatementContext *ctx) = 0;

  virtual void enterGraphAddNodesCall(BaseParser::GraphAddNodesCallContext *ctx) = 0;
  virtual void exitGraphAddNodesCall(BaseParser::GraphAddNodesCallContext *ctx) = 0;

  virtual void enterGraphAddEdgesCall(BaseParser::GraphAddEdgesCallContext *ctx) = 0;
  virtual void exitGraphAddEdgesCall(BaseParser::GraphAddEdgesCallContext *ctx) = 0;

  virtual void enterGraphRemoveNodesCall(BaseParser::GraphRemoveNodesCallContext *ctx) = 0;
  virtual void exitGraphRemoveNodesCall(BaseParser::GraphRemoveNodesCallContext *ctx) = 0;

  virtual void enterGraphRemoveEdgesCall(BaseParser::GraphRemoveEdgesCallContext *ctx) = 0;
  virtual void exitGraphRemoveEdgesCall(BaseParser::GraphRemoveEdgesCallContext *ctx) = 0;

  virtual void enterQueryStatement(BaseParser::QueryStatementContext *ctx) = 0;
  virtual void exitQueryStatement(BaseParser::QueryStatementContext *ctx) = 0;

  virtual void enterShowgraph(BaseParser::ShowgraphContext *ctx) = 0;
  virtual void exitShowgraph(BaseParser::ShowgraphContext *ctx) = 0;

  virtual void enterFunction(BaseParser::FunctionContext *ctx) = 0;
  virtual void exitFunction(BaseParser::FunctionContext *ctx) = 0;

  virtual void enterReturnType(BaseParser::ReturnTypeContext *ctx) = 0;
  virtual void exitReturnType(BaseParser::ReturnTypeContext *ctx) = 0;

  virtual void enterParamList(BaseParser::ParamListContext *ctx) = 0;
  virtual void exitParamList(BaseParser::ParamListContext *ctx) = 0;

  virtual void enterParam(BaseParser::ParamContext *ctx) = 0;
  virtual void exitParam(BaseParser::ParamContext *ctx) = 0;

  virtual void enterType(BaseParser::TypeContext *ctx) = 0;
  virtual void exitType(BaseParser::TypeContext *ctx) = 0;

  virtual void enterDrawgraph(BaseParser::DrawgraphContext *ctx) = 0;
  virtual void exitDrawgraph(BaseParser::DrawgraphContext *ctx) = 0;

  virtual void enterDrawmotifs(BaseParser::DrawmotifsContext *ctx) = 0;
  virtual void exitDrawmotifs(BaseParser::DrawmotifsContext *ctx) = 0;

  virtual void enterDrawMotifOption(BaseParser::DrawMotifOptionContext *ctx) = 0;
  virtual void exitDrawMotifOption(BaseParser::DrawMotifOptionContext *ctx) = 0;

  virtual void enterDrawOption(BaseParser::DrawOptionContext *ctx) = 0;
  virtual void exitDrawOption(BaseParser::DrawOptionContext *ctx) = 0;

  virtual void enterVertexDrawOption(BaseParser::VertexDrawOptionContext *ctx) = 0;
  virtual void exitVertexDrawOption(BaseParser::VertexDrawOptionContext *ctx) = 0;

  virtual void enterEdgeDrawOption(BaseParser::EdgeDrawOptionContext *ctx) = 0;
  virtual void exitEdgeDrawOption(BaseParser::EdgeDrawOptionContext *ctx) = 0;

  virtual void enterColorMapping(BaseParser::ColorMappingContext *ctx) = 0;
  virtual void exitColorMapping(BaseParser::ColorMappingContext *ctx) = 0;

  virtual void enterContinuousMapping(BaseParser::ContinuousMappingContext *ctx) = 0;
  virtual void exitContinuousMapping(BaseParser::ContinuousMappingContext *ctx) = 0;

  virtual void enterDrawBoolLiteral(BaseParser::DrawBoolLiteralContext *ctx) = 0;
  virtual void exitDrawBoolLiteral(BaseParser::DrawBoolLiteralContext *ctx) = 0;

  virtual void enterFunctionCall(BaseParser::FunctionCallContext *ctx) = 0;
  virtual void exitFunctionCall(BaseParser::FunctionCallContext *ctx) = 0;

  virtual void enterArgumentList(BaseParser::ArgumentListContext *ctx) = 0;
  virtual void exitArgumentList(BaseParser::ArgumentListContext *ctx) = 0;

  virtual void enterSleepStatement(BaseParser::SleepStatementContext *ctx) = 0;
  virtual void exitSleepStatement(BaseParser::SleepStatementContext *ctx) = 0;

  virtual void enterBlock(BaseParser::BlockContext *ctx) = 0;
  virtual void exitBlock(BaseParser::BlockContext *ctx) = 0;

  virtual void enterReturnStatement(BaseParser::ReturnStatementContext *ctx) = 0;
  virtual void exitReturnStatement(BaseParser::ReturnStatementContext *ctx) = 0;

  virtual void enterBreakStatement(BaseParser::BreakStatementContext *ctx) = 0;
  virtual void exitBreakStatement(BaseParser::BreakStatementContext *ctx) = 0;

  virtual void enterContinueStatement(BaseParser::ContinueStatementContext *ctx) = 0;
  virtual void exitContinueStatement(BaseParser::ContinueStatementContext *ctx) = 0;

  virtual void enterPrintStatement(BaseParser::PrintStatementContext *ctx) = 0;
  virtual void exitPrintStatement(BaseParser::PrintStatementContext *ctx) = 0;

  virtual void enterPrintExpr(BaseParser::PrintExprContext *ctx) = 0;
  virtual void exitPrintExpr(BaseParser::PrintExprContext *ctx) = 0;

  virtual void enterPrintArrayStatement(BaseParser::PrintArrayStatementContext *ctx) = 0;
  virtual void exitPrintArrayStatement(BaseParser::PrintArrayStatementContext *ctx) = 0;

  virtual void enterEdgePrint(BaseParser::EdgePrintContext *ctx) = 0;
  virtual void exitEdgePrint(BaseParser::EdgePrintContext *ctx) = 0;

  virtual void enterNodePrint(BaseParser::NodePrintContext *ctx) = 0;
  virtual void exitNodePrint(BaseParser::NodePrintContext *ctx) = 0;

  virtual void enterGraphPrint(BaseParser::GraphPrintContext *ctx) = 0;
  virtual void exitGraphPrint(BaseParser::GraphPrintContext *ctx) = 0;

  virtual void enterBoolTrueExpr(BaseParser::BoolTrueExprContext *ctx) = 0;
  virtual void exitBoolTrueExpr(BaseParser::BoolTrueExprContext *ctx) = 0;

  virtual void enterTimerExpr(BaseParser::TimerExprContext *ctx) = 0;
  virtual void exitTimerExpr(BaseParser::TimerExprContext *ctx) = 0;

  virtual void enterIdExpr(BaseParser::IdExprContext *ctx) = 0;
  virtual void exitIdExpr(BaseParser::IdExprContext *ctx) = 0;

  virtual void enterBoolFalseExpr(BaseParser::BoolFalseExprContext *ctx) = 0;
  virtual void exitBoolFalseExpr(BaseParser::BoolFalseExprContext *ctx) = 0;

  virtual void enterArrayAccessExpr(BaseParser::ArrayAccessExprContext *ctx) = 0;
  virtual void exitArrayAccessExpr(BaseParser::ArrayAccessExprContext *ctx) = 0;

  virtual void enterSetLitExpr(BaseParser::SetLitExprContext *ctx) = 0;
  virtual void exitSetLitExpr(BaseParser::SetLitExprContext *ctx) = 0;

  virtual void enterSetSizeExpr(BaseParser::SetSizeExprContext *ctx) = 0;
  virtual void exitSetSizeExpr(BaseParser::SetSizeExprContext *ctx) = 0;

  virtual void enterArray2DAccessExpr(BaseParser::Array2DAccessExprContext *ctx) = 0;
  virtual void exitArray2DAccessExpr(BaseParser::Array2DAccessExprContext *ctx) = 0;

  virtual void enterArrayPrint(BaseParser::ArrayPrintContext *ctx) = 0;
  virtual void exitArrayPrint(BaseParser::ArrayPrintContext *ctx) = 0;

  virtual void enterInfExpr(BaseParser::InfExprContext *ctx) = 0;
  virtual void exitInfExpr(BaseParser::InfExprContext *ctx) = 0;

  virtual void enterFuncExpr(BaseParser::FuncExprContext *ctx) = 0;
  virtual void exitFuncExpr(BaseParser::FuncExprContext *ctx) = 0;

  virtual void enterSetContainsExpr(BaseParser::SetContainsExprContext *ctx) = 0;
  virtual void exitSetContainsExpr(BaseParser::SetContainsExprContext *ctx) = 0;

  virtual void enterMulDivExpr(BaseParser::MulDivExprContext *ctx) = 0;
  virtual void exitMulDivExpr(BaseParser::MulDivExprContext *ctx) = 0;

  virtual void enterNotExpr(BaseParser::NotExprContext *ctx) = 0;
  virtual void exitNotExpr(BaseParser::NotExprContext *ctx) = 0;

  virtual void enterIntExpr(BaseParser::IntExprContext *ctx) = 0;
  virtual void exitIntExpr(BaseParser::IntExprContext *ctx) = 0;

  virtual void enterSetPopExpr(BaseParser::SetPopExprContext *ctx) = 0;
  virtual void exitSetPopExpr(BaseParser::SetPopExprContext *ctx) = 0;

  virtual void enterParenExpr(BaseParser::ParenExprContext *ctx) = 0;
  virtual void exitParenExpr(BaseParser::ParenExprContext *ctx) = 0;

  virtual void enterRealExpr(BaseParser::RealExprContext *ctx) = 0;
  virtual void exitRealExpr(BaseParser::RealExprContext *ctx) = 0;

  virtual void enterLogicalExpr(BaseParser::LogicalExprContext *ctx) = 0;
  virtual void exitLogicalExpr(BaseParser::LogicalExprContext *ctx) = 0;

  virtual void enterAddSubExpr(BaseParser::AddSubExprContext *ctx) = 0;
  virtual void exitAddSubExpr(BaseParser::AddSubExprContext *ctx) = 0;

  virtual void enterUnaryMinusExpr(BaseParser::UnaryMinusExprContext *ctx) = 0;
  virtual void exitUnaryMinusExpr(BaseParser::UnaryMinusExprContext *ctx) = 0;

  virtual void enterSized2DArray(BaseParser::Sized2DArrayContext *ctx) = 0;
  virtual void exitSized2DArray(BaseParser::Sized2DArrayContext *ctx) = 0;

  virtual void enterSizedArray(BaseParser::SizedArrayContext *ctx) = 0;
  virtual void exitSizedArray(BaseParser::SizedArrayContext *ctx) = 0;

  virtual void enterUnsizedArray(BaseParser::UnsizedArrayContext *ctx) = 0;
  virtual void exitUnsizedArray(BaseParser::UnsizedArrayContext *ctx) = 0;

  virtual void enterArrayInitializer(BaseParser::ArrayInitializerContext *ctx) = 0;
  virtual void exitArrayInitializer(BaseParser::ArrayInitializerContext *ctx) = 0;

  virtual void enterAssignmentStatement(BaseParser::AssignmentStatementContext *ctx) = 0;
  virtual void exitAssignmentStatement(BaseParser::AssignmentStatementContext *ctx) = 0;

  virtual void enterArray2DAssignStmt(BaseParser::Array2DAssignStmtContext *ctx) = 0;
  virtual void exitArray2DAssignStmt(BaseParser::Array2DAssignStmtContext *ctx) = 0;

  virtual void enterArrayAssignStmt(BaseParser::ArrayAssignStmtContext *ctx) = 0;
  virtual void exitArrayAssignStmt(BaseParser::ArrayAssignStmtContext *ctx) = 0;

  virtual void enterWeights(BaseParser::WeightsContext *ctx) = 0;
  virtual void exitWeights(BaseParser::WeightsContext *ctx) = 0;


};

