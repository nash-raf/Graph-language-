from pathlib import Path
import sys
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));import series
series.build('01_dispatch_cachelines')
series.tests('01_dispatch_cachelines',['run_empty_partition_effects_tests.sh','run_array_frontier_exec_tests.sh','run_round_spatial_exec_tests.sh'])
series.compare('01_dispatch_cachelines',record_decision=False)
