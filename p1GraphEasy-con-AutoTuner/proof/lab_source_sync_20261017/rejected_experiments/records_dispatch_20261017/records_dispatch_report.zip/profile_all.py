import subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent
for name in ['profile_phases.py','capture_perf.py']:
 subprocess.run([sys.executable,'-u',str(P/name)],cwd=P,check=True)
