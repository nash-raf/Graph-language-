from pathlib import Path
import sys
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));import series
series.tests('01_segment_view',['run_segment_view_tests.sh','run_array_frontier_exec_tests.sh','run_array_preparation_exec_tests.sh','run_empty_partition_effects_tests.sh','run_array_frontier_lease_tests.sh'])
series.build('01_segment_view',regenerate=True)
