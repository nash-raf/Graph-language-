#ifndef ASTBUILDER_H
#define ASTBUILDER_H

#include "BaseBaseVisitor.h"
#include "ASTNode.h"
#include <memory>

class ASTBuilder : public BaseBaseVisitor
{
public:
    antlrcpp::Any visitProgram(BaseParser::ProgramContext *ctx) override;
    antlrcpp::Any visitStatement(BaseParser::StatementContext *ctx) override;
    antlrcpp::Any visitExpr(BaseParser::ExprContext *ctx);

    antlrcpp::Any visitVarDecl(BaseParser::VarDeclContext *ctx);
    antlrcpp::Any visitAssignmentStatement(BaseParser::AssignmentStatementContext *ctx) override;

    antlrcpp::Any visitConditionalStatement(BaseParser::ConditionalStatementContext *ctx) override;
    antlrcpp::Any visitCondition(BaseParser::ConditionContext *ctx);
    antlrcpp::Any visitBlock(BaseParser::BlockContext *ctx) override;
    // antlrcpp::Any visitLoopStatement(BaseParser::LoopStatementContext* ctx) override;
    antlrcpp::Any visitWhileStatement(BaseParser::WhileStatementContext *ctx) override;
    antlrcpp::Any visitForeachStatement(BaseParser::ForeachStatementContext *ctx) override;

    antlrcpp::Any visitArrayAssignStmt(BaseParser::ArrayAssignStmtContext *ctx) override;
    antlrcpp::Any visitArray2DAssignStmt(BaseParser::Array2DAssignStmtContext *ctx);
    antlrcpp::Any visitFunction(BaseParser::FunctionContext *ctx) override;
    antlrcpp::Any visitFunctionCall(BaseParser::FunctionCallContext *ctx) override;
    antlrcpp::Any visitUnweightedGraphDef(BaseParser::UnweightedGraphDefContext *ctx) override;
    antlrcpp::Any visitWeightedGraphDef(BaseParser::WeightedGraphDefContext *ctx) override;
    // Plan rows 1-4: the new declaration and mutation surface.  Each builds the
    // same AST node the old spelling builds, so the backend is untouched.
    antlrcpp::Any visitPlainGraphDef(BaseParser::PlainGraphDefContext *ctx) override;
    antlrcpp::Any visitLoadGraphDef(BaseParser::LoadGraphDefContext *ctx) override;
    antlrcpp::Any visitGraphAddNodesCall(BaseParser::GraphAddNodesCallContext *ctx) override;
    antlrcpp::Any visitGraphAddEdgesCall(BaseParser::GraphAddEdgesCallContext *ctx) override;
    antlrcpp::Any visitGraphRemoveNodesCall(BaseParser::GraphRemoveNodesCallContext *ctx) override;
    antlrcpp::Any visitGraphRemoveEdgesCall(BaseParser::GraphRemoveEdgesCallContext *ctx) override;
    // Rows 5-7: member-style loop headers (same foreach node, CSR iteration).
    antlrcpp::Any visitForeachNodes(BaseParser::ForeachNodesContext *ctx) override;
    antlrcpp::Any visitForeachEdges(BaseParser::ForeachEdgesContext *ctx) override;
    antlrcpp::Any visitForeachNeighbors(BaseParser::ForeachNeighborsContext *ctx) override;
    // Row 8: membership checks.  hasNode desugars to set membership on G.nodes;
    // hasEdge lowers through a runtime pair lookup (FunctionCallNode "hasEdge").
    antlrcpp::Any visitHasNodeCheck(BaseParser::HasNodeCheckContext *ctx) override;
    antlrcpp::Any visitHasEdgeCheck(BaseParser::HasEdgeCheckContext *ctx) override;
    antlrcpp::Any visitHasNodeCall(BaseParser::HasNodeCallContext *ctx) override;
    antlrcpp::Any visitHasEdgeCall(BaseParser::HasEdgeCallContext *ctx) override;
    antlrcpp::Any visitMotifSearchDecl(BaseParser::MotifSearchDeclContext *ctx) override;

    antlrcpp::Any visitQueryStatement(BaseParser::QueryStatementContext *ctx) override;

    antlrcpp::Any visitPrintExpr(BaseParser::PrintExprContext *ctx) override;
    antlrcpp::Any visitPrintStatement(BaseParser::PrintStatementContext *ctx) override;
    antlrcpp::Any visitSleepStatement(BaseParser::SleepStatementContext *ctx) override;
    antlrcpp::Any visitSetDecl(BaseParser::SetDeclContext *ctx);
    antlrcpp::Any visitSetInitializer(BaseParser::SetInitializerContext *ctx);
    antlrcpp::Any visitSetOperation(BaseParser::SetOperationContext *ctx);
    antlrcpp::Any visitSetExpr(BaseParser::SetExprContext *ctx);
    antlrcpp::Any visitSetUnion(BaseParser::SetUnionContext *ctx);
    antlrcpp::Any visitSetIntersect(BaseParser::SetIntersectContext *ctx);
    antlrcpp::Any visitSetId(BaseParser::SetIdContext *ctx);
    antlrcpp::Any visitSetLiteral(BaseParser::SetLiteralContext *ctx);
    antlrcpp::Any visitParenSet(BaseParser::ParenSetContext *ctx);
    antlrcpp::Any visitSetAddMethod(BaseParser::SetAddMethodContext *ctx);
    antlrcpp::Any visitSetRemoveMethod(BaseParser::SetRemoveMethodContext *ctx);
    antlrcpp::Any visitSetMethodCall(BaseParser::SetMethodCallContext *ctx);
    antlrcpp::Any visitSwapStatement(BaseParser::SwapStatementContext *ctx);
    antlrcpp::Any visitSetContainsExpr(BaseParser::SetContainsExprContext *ctx);
    SetTargetKind parseSetTarget(BaseParser::SetTargetContext *ctx);
    
private:
    std::shared_ptr<GraphConditionNode> buildGraphCondition(BaseParser::GraphConditionContext *ctx);
};

#endif // ASTBUILDER_H