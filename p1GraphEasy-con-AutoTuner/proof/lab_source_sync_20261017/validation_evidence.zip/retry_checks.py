from pathlib import Path
import subprocess,json,os
r=Path(__file__).resolve().parent;src=r/'source';results=[]
env=dict(os.environ,LLVM_CONFIG='/usr/local/llvm-20-polly-rtti/bin/llvm-config')
checks=[('run_program_array_tests',['bash','test/run_program_array_tests.sh']),('iterator_phase_regressions',['python3','test/pdg_tdg_verification/test_autotuner_iterator_phases.py']),('autotuner_frequency_regressions',['python3','test/pdg_tdg_verification/test_autotuner_frequency.py','--frontend'])]
for name,cmd in checks:
 with (r/(name+'.retry.log')).open('w') as log:p=subprocess.run(cmd,cwd=src,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
 results.append({'name':name,'exit_code':p.returncode});(r/'retry_validation.json').write_text(json.dumps({'complete':False,'results':results},indent=2))
(r/'retry_validation.json').write_text(json.dumps({'complete':True,'passed':all(x['exit_code']==0 for x in results),'results':results},indent=2))
