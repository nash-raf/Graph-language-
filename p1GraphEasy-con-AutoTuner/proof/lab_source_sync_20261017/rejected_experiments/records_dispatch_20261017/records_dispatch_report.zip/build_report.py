from pathlib import Path
import json,hashlib,csv,math,statistics
P=Path(__file__).resolve().parent;C=Path((P/'installed_source_path.txt').read_text().strip())
assert (P/'evaluation_complete.json').exists()
snapshot=json.loads((P/'installed_baseline_hashes.json').read_text());core=json.loads((P.parent/'sssp_dense_20261017/installed_baseline_hashes.json').read_text())
changed=[k for k,v in core.items() if not (C/k).exists() or hashlib.sha256((C/k).read_bytes()).hexdigest()!=v]
existing={k:v for k,v in snapshot.items() if (C/k).exists()};absent=[k for k in snapshot if not (C/k).exists()]
changed+= [k for k,v in existing.items() if hashlib.sha256((C/k).read_bytes()).hexdigest()!=v]
audit={'installed_version_changed':bool(changed),'changed_files':changed,'installed_core_files_checked':len(core),'present_snapshot_files_checked':len(existing),'benchmark_only_snapshot_files_absent_from_installed_tree':absent,'retained_installed_version':'packing_regression_20261017/03_completion_batch','source_path':str(C),'note':'monotonic_timer.o belongs to the benchmark snapshot and is not an installed-tree file; not treated as a deletion.'};assert not changed,audit
stages=['01_dispatch_cachelines','02_preparation_versioning','03_worker_budget_scope','04_preparation_team_fusion'];decisions=[];allrows=[];validations=0;measurements=0;confirm_launches=0
for st in stages:
 decisions.append(json.loads((P/st/'decision.json').read_text()))
 for line in (P/st/'measurements.jsonl').read_text().splitlines():
  x=json.loads(line)
  if x['phase']=='validate':assert x['exit_code']==0 and x.get('validation') is not None;validations+=1
  if x['phase']=='measure':measurements+=1
  if x['phase']=='confirm':confirm_launches+=1
 for r in json.loads((P/st/'results.json').read_text()):
  allrows.append({'stage':st,'algorithm':r['algorithm'],'graph':r['graph'],'current_p1_ms':r['means']['baseline']*1000,'candidate_p1_ms':r['means']['candidate']*1000,'graptor_ms':r['means']['graptor']*1000,'current_p1_median_ms':r['medians']['baseline']*1000,'candidate_p1_median_ms':r['medians']['candidate']*1000,'graptor_median_ms':r['medians']['graptor']*1000,'current_over_candidate':r['improvement'],'median_current_over_candidate':r['median_improvement'],'graptor_over_current':r['means']['graptor']/r['means']['baseline'],'graptor_over_candidate':r['graptor_over_candidate'],'validated':r['validated'],'installed':False})
def csvout(name,rr):
 with (P/name).open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
csvout('all_trials.csv',allrows)
best='02_preparation_versioning';primary=[r for r in allrows if r['stage']==best];csvout('benchmark_results.csv',primary)
geo=lambda xs:math.exp(statistics.mean(math.log(x) for x in xs));summary={}
for alg in ['sssp','bfs','cc','pagerank','overall']:
 rr=[r for r in primary if alg=='overall' or r['algorithm']==alg];summary[alg]={'cases':len(rr),'current_over_candidate':geo([r['current_over_candidate'] for r in rr]),'median_current_over_candidate':geo([r['median_current_over_candidate'] for r in rr]),'graptor_over_current':geo([r['graptor_over_current'] for r in rr]),'graptor_over_candidate':geo([r['graptor_over_candidate'] for r in rr]),'current_wins_vs_graptor':sum(r['graptor_over_current']>1 for r in rr),'candidate_wins_vs_graptor':sum(r['graptor_over_candidate']>1 for r in rr)}
profile=json.loads((P/'profiles/fusion_phase_summary.json').read_text())
for r in profile:
 if r['stage']=='04_preparation_team_fusion':
  for name in ['count','fill']:r['median_diagnostic_phases_ms'].pop(name,None)
report={'installed':False,'retained_installed_version':audit['retained_installed_version'],'workers':32,'primary_repeats':5,'cases_per_trial':12,'unique_graphs':10,'candidate_trials':4,'validated_framework_cases':validations,'primary_timed_launches':measurements,'extra_paired_confirmation_launches':confirm_launches,'validation_failures':0,'missing_pairs':0,'all_candidates_rejected':True,'decisions':decisions,'reported_trial':best,'reported_trial_status':'Rejected: 0.3% mean improvement, 0.3% median regression; no repeatable overall gain.','primary':primary,'summary':summary,'diagnostic_phases':profile,'installed_audit':audit,'timing_policy':'Five fresh whole-process launches per variant, 32 configured workers. Loading, initialization, computation, worker teardown and process exit included; compilation, untimed reference validation, warmup and instrumented profiles excluded. Variant order rotated. Warm filesystem cache. Every primary sample retained. Extra paired confirmations kept separately.','semantics':'No algorithm/graph-name dispatch, no input changes, no duplicate suppression, no TDG bypass, and no reduced graph worker budget. Pure preparation uses the existing general grain policy.','sssp_weights':'Shared deterministic positive integer weights, seed 2358.','limitations':['Only the established 12-case suite on 10 graph IDs; not a rerun of all 273 graphs.','Hardware perf sampling unavailable: perf_event_paranoid=4. Diagnostic timing instrumentation was used instead.','Instrumented phase times are diagnostic; weight-index construction is nested within record preparation. Fused count/fill phases were not separately instrumented; their absent values do not mean zero cost.']}
(P/'final_audit.json').write_text(json.dumps(audit,indent=2));(P/'report.json').write_text(json.dumps(report,indent=2))
lines=['Record preparation and dispatch investigation -- 2026-10-17','','Result: all four candidates rejected. Installed P1 remains '+audit['retained_installed_version']+'. Installed compiler/runtime hashes match the preserved baseline.','','Protocol: '+report['timing_policy'],'Scope: 12 cases / 10 distinct graph IDs: 8 SSSP, 2 BFS, 1 CC, 1 PageRank. Four candidates, '+str(validations)+' reference-validated framework cases, '+str(measurements)+' primary timed launches, '+str(confirm_launches)+' extra paired confirmation launches. No validation failures or missing pairs.','','Trial | current P1 / candidate mean geomean | median geomean | decision']
for d in decisions:lines.append(f"{d['stage']} | {d['geomean_improvement']:.4f}x | {d['geomean_median_improvement']:.4f}x | REJECTED")
lines+=['','Above 1x in current/candidate columns means the candidate is faster. Reported detail block is the near-flat rejected preparation-versioning trial; candidate results must not be presented as installed P1.','','Algorithm | graph | current P1 ms | rejected candidate ms | Graptor ms']
for r in primary:lines.append(f"{r['algorithm']} | {r['graph']} | {r['current_p1_ms']:.4f} | {r['candidate_p1_ms']:.4f} | {r['graptor_ms']:.4f}")
lines+=['','Fresh baseline diagnostic phases before experiments (median of three instrumented runs):']
for r in json.loads((P/'profiles/phase_summary.json').read_text()):
 x=r['median_diagnostic_phases_ms'];lines.append(f"{r['graph']}: record preparation {x['records']:.3f} ms, dispatch {x['dispatch']:.3f} ms, compaction {x['compaction']:.3f} ms. Weight-index construction {x['weight_indices']:.3f} ms is already included in preparation.")
lines+=['','Changes tried: isolate claim/cancellation/completion coherence lines; version pair-only packed preparation by ownership and eliminate unreachable lifecycle/side-array work; hoist invariant per-worker budget scope; fuse preparation count/prefix/fill into one worker-team region. All retained callback, occurrence, order, cancellation and budget contracts.','','Fusion confirmed regressions: '+json.dumps(decisions[-1]['confirmed_regressions']), '','Conclusion: these scheduling and loop-bookkeeping changes did not remove the dominant intermediate materialization cost. A future representation/lowering change could avoid per-edge record copying under explicit topology-stability and ownership/order proofs, retaining materialization fallback when those proofs do not hold. This future change was not implemented or benchmarked here.','']+report['limitations']+['','Remote artifacts: '+str(P)]
(P/'report.txt').write_text('\n'.join(lines)+'\n')
print(json.dumps({'audit':audit,'summary':summary,'validation_cases':validations,'primary_launches':measurements,'confirmation_launches':confirm_launches,'selected_rows':[r for r in primary if any(x in r['graph'] for x in ['DSJC','slashdot','roadNet','usroads'])]},indent=2))
