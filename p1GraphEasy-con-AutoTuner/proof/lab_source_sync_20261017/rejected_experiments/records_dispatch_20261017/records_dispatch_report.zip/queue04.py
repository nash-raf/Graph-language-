from pathlib import Path
import time,subprocess,sys
P=Path(__file__).resolve().parent
while not (P/'03_worker_budget_scope/decision.json').exists():time.sleep(3)
subprocess.run([sys.executable,'-u',str(P/'run04.py')],cwd=P,check=True)
