from pathlib import Path
import sys
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));import series
series.tests('03_view_dispatch_versioning',['run_segment_view_tests.sh','run_array_frontier_exec_tests.sh','run_array_preparation_exec_tests.sh','run_empty_partition_effects_tests.sh'])
series.build('03_view_dispatch_versioning',regenerate=True)
series.compare('03_view_dispatch_versioning',record_decision=False)
