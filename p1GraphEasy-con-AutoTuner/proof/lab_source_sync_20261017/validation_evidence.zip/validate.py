from pathlib import Path
import subprocess,json,shlex,os,traceback
root=Path(__file__).resolve().parent;src=root/'source';base=Path('/media/readinggroup/Storage/splash/bench/p1graph_audit/p1GraphEasy-con-AutoTuner')
results=[]
def run(name,cmd,timeout=1200):
 with (root/(name+'.log')).open('w') as log:
  p=subprocess.run(cmd,cwd=src,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
 results.append({'name':name,'exit_code':p.returncode});(root/'validation.json').write_text(json.dumps({'complete':False,'results':results},indent=2))
 if p.returncode:raise RuntimeError(name+' failed')
try:
 cfg='/usr/local/llvm-20-polly-rtti/bin/llvm-config'
 if not Path(cfg).exists():cfg='llvm-config-20'
 def llvm(flag):return shlex.split(subprocess.check_output([cfg,flag],text=True))
 flags=[x for x in llvm('--cxxflags') if x!='-fno-exceptions']+['-O2','-mavx2','-march=native','-std=c++17','-fexceptions','-pthread','-I/usr/local/include/antlr4-runtime','-Igenerated','-iquote','.','-I'+subprocess.check_output([cfg,'--includedir'],text=True).strip()+'/polly']
 objs=root/'objects';objs.mkdir(exist_ok=True)
 changed=['main','IRGenVisitor','graph_frontier_lowering','AutoTunerPass']
 for n in changed:run('compile_'+n,['g++','-c',*flags,n+'.cpp','-o',str(objs/(n+'.o'))])
 allobjs=[str(objs/p.name) if p.stem in changed else str(p) for p in sorted((base/'build_lowmem').glob('*.o'))]
 run('link_compiler',['g++',*allobjs,*llvm('--ldflags'),'-Wl,--no-keep-memory','-pthread','-lantlr4-runtime',*llvm('--libs'),*llvm('--system-libs'),'-o',str(src/'GraphProgram')])
 tests=['run_stable_compaction_tests','run_array_append_epoch_tests','run_array_frontier_lease_tests','run_empty_partition_effects_tests','run_array_preparation_exec_tests','run_array_frontier_exec_tests','run_general_frontier_optimization_tests','run_program_array_tests']
 for t in tests:run(t,['bash','test/'+t+'.sh'])
 run('iterator_phases',['python3','test/pdg_tdg_verification/test_autotuner_iterator_phases.py','--help'])
 (root/'validation.json').write_text(json.dumps({'complete':True,'passed':True,'results':results},indent=2))
except Exception as e:
 (root/'validation.json').write_text(json.dumps({'complete':True,'passed':False,'error':str(e),'results':results},indent=2));traceback.print_exc()
