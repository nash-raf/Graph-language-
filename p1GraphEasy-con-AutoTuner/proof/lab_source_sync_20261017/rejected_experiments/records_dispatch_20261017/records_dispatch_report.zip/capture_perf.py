from pathlib import Path
import sys,json,subprocess
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P));import series
for c in series.plan:
 if c['algorithm']!='sssp' or not any(x in c['row']['graph'] for x in ['DSJC','slashdot']):continue
 for fw in ['p1','graptor']:
  if fw=='p1':
   cwd=series.bench.case_dir(P/'00_baseline/cases','sssp',c['row']);cmd=[str(cwd/'timed')]
  else:cmd,env,cwd=series.bench.command(series.R,P/'00_baseline/cases','sssp','graptor',c['row'],32,False)
  tag=fw+'_'+c['row']['graph'].replace('/','_');spec=P/'profiles'/(tag+'.command.json');spec.write_text(json.dumps({'framework':fw,'command':cmd,'cwd':str(cwd)}))
  data=P/'profiles'/(tag+'.perf.data')
  with (P/'profiles'/(tag+'.record.log')).open('w') as log:subprocess.run(['perf','record','-F','999','-e','cycles','-o',str(data),'--','python3',str(P/'perf_workload.py'),str(spec)],stdout=log,stderr=subprocess.STDOUT,check=True)
  r=subprocess.run(['perf','report','--stdio','--no-children','--comms=timed,graptor_sssp','--percent-limit','0.8','-i',str(data)],capture_output=True,text=True,check=True)
  (P/'profiles'/(tag+'.report.txt')).write_text(r.stdout);print(tag,r.stdout,flush=True)
