from pathlib import Path
import sys
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));import series
series.build('02_preparation_versioning')
series.tests('02_preparation_versioning',['run_array_preparation_exec_tests.sh','run_array_frontier_exec_tests.sh','run_array_frontier_lease_tests.sh','run_empty_partition_effects_tests.sh'])
series.compare('02_preparation_versioning',record_decision=False)
