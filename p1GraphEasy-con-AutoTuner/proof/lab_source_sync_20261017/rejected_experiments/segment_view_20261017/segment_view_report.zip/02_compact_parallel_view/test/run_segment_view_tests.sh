#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP="$(mktemp -d)"
trap 'if (($?)); then echo "segment test logs: $TMP"; else rm -rf "$TMP"; fi' EXIT
for mode in normal sanitized no_scratch; do
 flags=(-O2)
 [[ "$mode" == sanitized ]] && flags=(-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer)
 [[ "$mode" == no_scratch ]] && flags+=(-DSGPL_EXEC_REUSE_BUFFERS=0)
 gcc "${flags[@]}" -std=gnu11 -pthread -I. test/segment_view_test.c autotuner_runtime.c parallel_runtime.c -lnlopt -lm -Wl,--wrap=malloc -Wl,--wrap=calloc -Wl,--wrap=pthread_create -o "$TMP/test"
 for workers in 1 4 32; do
  ASAN_OPTIONS=detect_leaks=0 SGPL_NUM_THREADS=$workers SGPL_ALLOW_HT=1 SGPL_SEGMENT_DEBUG=1 "$TMP/test" > "$TMP/${mode}_${workers}.log" 2>&1 || { cat "$TMP/${mode}_${workers}.log"; exit 1; }
  tail -1 "$TMP/${mode}_${workers}.log"
 done
done
