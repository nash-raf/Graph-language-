#ifndef IRGENVISITOR_H
#define IRGENVISITOR_H

#include <llvm/IR/LLVMContext.h>
#include <llvm/IR/IRBuilder.h>
#include <llvm/IR/Module.h>
#include <unordered_map>
#include <unordered_set>
#include <string>
#include <utility>

#include "ASTNode.h"
#include "MotifPattern.h"
#include "MotifIRBuilder.h"

class IRGenVisitor
{
public:
    IRGenVisitor(llvm::LLVMContext &C,
                 llvm::Module &M,
                 llvm::IRBuilder<> &B,
                 const std::string &backend = "cpu",
                 std::string sourceDir = ".")
        : Context(C), Module(M), Builder(B), SelectedIRBackend(backend),
          SourceDir(std::move(sourceDir))
    {
        // Build the Graph struct type: { i64, i64, i64*, i32*, i32* }
        llvm::Type *I64 = llvm::Type::getInt64Ty(Context);
        llvm::Type *I32P = llvm::PointerType::get(llvm::Type::getInt32Ty(Context), 0);
        llvm::Type *I64P = llvm::PointerType::get(llvm::Type::getInt64Ty(Context), 0);
        // { i64 n, i64 m, i64* row_ptr, i32* col_idx, i32* weights, i32 directed }
        // `directed` is appended so the field indices the rest of IRGen already
        // uses (0..4) are unchanged and autotuner_runtime.c's hard-coded byte
        // offsets 16/24/32 stay valid.
        GraphTy = llvm::StructType::create(
            Context,
            {I64, I64, I64P, I32P, I32P, llvm::Type::getInt32Ty(Context)},
            "struct.Graph");
        // Must mirror MotifMatchesRuntime in runtime.c exactly
        // ({i32 count, i32 var_count, i32* bindings, i32 capacity}, 24 bytes,
        // align 8) so a value produced by the runtime path and one produced by
        // the IR path stay interchangeable.
        MotifMatchesTy = llvm::StructType::create(
            Context,
            {llvm::Type::getInt32Ty(Context), llvm::Type::getInt32Ty(Context),
             I32P, llvm::Type::getInt32Ty(Context)},
            "struct.MotifMatches");

        readBackendFlags();
    }

    /// Entry point: lower the AST root into LLVM IR
    void visitProgram(ProgramNodePtr prog);

    llvm::Value *visitVarDecl(VarDeclNode *decl);
    llvm::Value *visitExpr(ASTNode *expr);
    void visitAssignment(AssignmentStmtNode *assign);
    void visitConditional(ConditionalNode *ifs);
    void visitBlock(BlockStmtNode *block);
    void visitReturnStmt(ReturnStmtNode *ret);
    void visitStatement(ASTNode *node);
    void visitWhile(WhileStmtNode *ws);
    void visitForEach(ForEachStmtNode *fs);
    void visitFunctionDecl(FunctionDeclNode *funcDecl);
    llvm::Value *visitGraphDecl(GraphDeclNode *G);
    llvm::Value *visitWeightedGraphDecl(WeightedGraphDeclNode *G);
    void visitQuery(QueryNode *Q);
    void emitBFS(QueryNode *Q);
    void emitBFSSrc(QueryNode *Q);
    void emitDFS(QueryNode *Q);
    void emitDFSSrc(QueryNode *Q);
    void emitBK(QueryNode *Q);
    void emitDijkstra(QueryNode *Q);
    void emitChromacity(QueryNode *Q);
    void emitFloydWarshall(QueryNode *Q);
    void emitMinCut(QueryNode *Q);
    void visitPrintStmt(PrintStmtNode *PS);
    void visitPrintArray(PrintArrayNode *PA);
    void visitSleepStmt(SleepStmtNode *SS);
    llvm::Value *evaluate(ASTNode *node);
    llvm::Function *getPrintfFunction();
    void visitGraphUpdate(GraphUpdateNode *upd);
    void visitShowGraph(ShowGraphNode *S);
    void visitDrawGraph(DrawGraphNode *D);
    void visitDrawMotifs(DrawMotifsNode *D);
    void emitEnsureInCsr(llvm::Value *graphPtr);
    // Non-zero while re-lowering a dense semiring-closure nest as its own
    // fallback, so the detector does not match the same loop again.
    int ClosureFallbackDepth = 0;
    llvm::Value *load2DArrayBase(const std::string &name);
    void visitMotifMatchesDecl(MotifMatchesDeclNode *M);
    MotifIRBuilder::GraphInputs loadMotifGraphInputs(const std::string &graphName,
                                                     const std::string &label);
    llvm::Value *emitMotifMatchesIR(const std::string &graphName,
                                    const std::string &label,
                                    const std::vector<MotifEdgeSpec> &edges,
                                    const std::vector<std::string> &varNames);
    void visitGraphListDecl(GraphListDeclNode *M);
    void visitGraphComprehension(GraphComprehensionNode *GC);

    void visitSetDecl(SetDeclNode *SD);
    void visitSetOperation(SetOperationNode *setOp);
    llvm::Value *visitSetExpr(ASTNode *expr);
    llvm::Value *visitSetBinaryExpr(SetBinaryExprNode *binExpr);
    llvm::SmallVector<ASTNode *, 8> flattenSetOperation(ASTNode *expr, const std::string &targetOp);
    void visitSetMethodCall(SetMethodCallNode *node);
    llvm::Value *visitSetContainsExpr(SetContainsExprNode *node);
    llvm::Value *visitSetPopExpr(SetPopExprNode *node);
    void visitSwapStmt(SwapStmtNode *node);

private:
    llvm::LLVMContext &Context;
    llvm::Module &Module;
    llvm::IRBuilder<> &Builder;
    std::string SelectedIRBackend;
    std::string SourceDir;

    enum class SetValueKind
    {
        Unknown,
        Nodes,
        Edges
    };

    std::unordered_map<std::string, llvm::Function *> FunctionProtos;

    std::unordered_map<std::string, llvm::Value *> NamedValues;
    llvm::AllocaInst *createEntryBlockAlloca(llvm::Function *function, const std::string &name, llvm::Type *ty = nullptr)
    {
        llvm::IRBuilder<> tmpBuilder(&function->getEntryBlock(), function->getEntryBlock().begin());
        if (!ty)
            ty = Builder.getInt32Ty();
        return tmpBuilder.CreateAlloca(ty, nullptr, name);
    }
    llvm::Type *getLLVMTypeForName(const std::string &typeName);
    llvm::Type *getLLVMTypeFromTypeKind(TypeKind kind);
    llvm::Type *getStorageValueType(llvm::Value *storage);
    llvm::Value *lookupNamedStorage(const std::string &name);
    llvm::Value *loadGraphValue(const std::string &name);
    llvm::StructType *GraphTy;
    std::unordered_map<std::string, llvm::Value *> GraphMap;
    llvm::StructType *MotifMatchesTy = nullptr;

    // Selected by environment variable, not a CLI flag: main.cpp forwards every
    // '-' argument to Polly's option parser, which would reject an unknown one.
    enum class MotifBackend
    {
        Runtime,
        IR
    };
    MotifBackend MotifBackendMode = MotifBackend::Runtime;
    bool MotifAdjacencyDriven = false;
    void readBackendFlags();

    std::unordered_map<std::string, llvm::Value *> MotifMatchesMap;
    std::unordered_map<std::string, llvm::Value *> GraphListMatchesMap;
    std::unordered_map<std::string, std::string> GraphListSourceMap;
    std::unordered_map<std::string, GraphDeclNode *> GraphAstMap;

    std::unordered_map<std::string, llvm::Value *> GraphNodesMap;
    std::unordered_map<std::string, llvm::Value *> GraphEdgesMap;
    std::unordered_map<std::string, SetValueKind> SetKinds;

    // Loop stack for break/continue support
    struct LoopInfo
    {
        llvm::BasicBlock *condBB;  // where continue jumps to
        llvm::BasicBlock *mergeBB; // where break jumps to
    };
    std::vector<LoopInfo> LoopStack;

    // 2D array metadata: name -> {rows, cols} extents (runtime i32 values)
    struct Array2DMeta
    {
        llvm::Value *rowsVal = nullptr;
        llvm::Value *colsVal = nullptr;
        bool isReal = false;
    };
    std::unordered_map<std::string, Array2DMeta> Array2DMap;

    // Dynamic arrays use pointer indirection (alloca ptr -> data) so swap is O(1)
    std::unordered_set<std::string> IndirectArrays;
    std::unordered_set<std::string> IndirectRealArrays;
    std::unordered_map<std::string, llvm::Value *> ArraySizes;

    std::unordered_map<uint64_t, uint32_t> EdgePairToId;
    std::vector<std::pair<int32_t, int32_t>> GlobalEdgePairs;
    llvm::GlobalVariable *EdgePairsGV = nullptr;
    uint64_t EdgePairsCount = 0;

    llvm::Value *RuntimeEdgePairsPtr = nullptr;
    llvm::Value *RuntimeEdgePairsCount = nullptr;
    bool EmittingTopLevel = false;

    void buildGlobalEdgeTable(ProgramNodePtr prog);
    void emitEdgePairsGlobal();
    std::vector<uint8_t> buildEdgeBlobForGraph(GraphDeclNode *G);
    SetValueKind inferSetKind(ASTNode *expr);
    uint32_t getOrAddEdgeId(int32_t u, int32_t v);
};

#endif // IRGENVISITOR_H
