from pathlib import Path
import sys,time,json,shutil,statistics,math,subprocess
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));import series
while not (P/'03_view_dispatch_versioning/decision.json').exists():time.sleep(3)
primary=json.loads((P/'03_view_dispatch_versioning/decision.json').read_text());evaluation={'installed':False,'primary':primary,'eligible_to_install':False,'selected':'03_view_dispatch_versioning'}
if primary['accepted']:
 W=P/'04_confirmation';W.mkdir()
 for f in (P/'03_view_dispatch_versioning').iterdir():
  if f.is_file() and f.suffix in ['.c','.cpp','.h','.inc']:shutil.copy2(f,W/f.name)
 (W/'cases').symlink_to(P/'03_view_dispatch_versioning/cases')
 confirmation=series.compare('04_confirmation',record_decision=False)
 a=json.loads((P/'03_view_dispatch_versioning/results.json').read_text());b=json.loads((W/'results.json').read_text());pool=[]
 for x,y in zip(a,b):
  assert (x['algorithm'],x['graph'])==(y['algorithm'],y['graph'])
  samples={v:x['samples'][v]+y['samples'][v] for v in x['samples']};means={v:statistics.mean(t) for v,t in samples.items()};medians={v:statistics.median(t) for v,t in samples.items()}
  pool.append({'algorithm':x['algorithm'],'graph':x['graph'],'means':means,'medians':medians,'current_over_candidate':means['baseline']/means['candidate'],'median_current_over_candidate':medians['baseline']/medians['candidate']})
 regressions=[r for r in pool if r['current_over_candidate']<.97 or r['median_current_over_candidate']<.97]
 evaluation.update(confirmation=confirmation,pooled=pool,pooled_regressions=regressions,eligible_to_install=confirmation['accepted'] and not regressions)
else:evaluation['reason']='Primary five-repeat comparison did not establish an overall improvement without regressions.'
(P/'final_evaluation.json').write_text(json.dumps(evaluation,indent=2));print('FINAL_EVALUATION',json.dumps({k:v for k,v in evaluation.items() if k!='pooled'}),flush=True)
subprocess.run([sys.executable,'-u',str(P/'profile_final.py')],cwd=P,check=True)
subprocess.run([sys.executable,'-u',str(P/'check_proofs03.py')],cwd=P,check=True)
(P/'evaluation_complete.json').write_text(json.dumps({'complete':True,'eligible_to_install':evaluation['eligible_to_install']}))
