from pathlib import Path
import importlib.util,os,tempfile,json
r=Path(__file__).resolve().parent;src=r/'source'
os.environ['LLVM_CONFIG']='/usr/local/llvm-20-polly-rtti/bin/llvm-config'
spec=importlib.util.spec_from_file_location('test_iterator',src/'test/pdg_tdg_verification/test_autotuner_iterator_phases.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
clean=m.clean_env
m.clean_env=lambda **kw:dict(clean(**kw),AUTOTUNER_HW_CALIB='/dev/null')
try:
 with tempfile.TemporaryDirectory(prefix='p1-iterator-default-calibration-') as temp:m.pass_checks(Path(temp))
 (r/'iterator_default_calibration.json').write_text(json.dumps({'passed':True,'calibration':'compiler defaults'},indent=2))
except Exception as e:
 (r/'iterator_default_calibration.json').write_text(json.dumps({'passed':False,'error':str(e),'calibration':'compiler defaults'},indent=2));raise
