from pathlib import Path
import sys,json,re,subprocess,os,shutil
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));import series
W=P/'01_segment_view';D=W/'proof_checks';D.mkdir(exist_ok=True)

if not (D/'test').exists():(D/'test').symlink_to(W/'test')
for f in W.glob('*.ll'):
 if not (D/f.name).exists():(D/f.name).symlink_to(f)
positive=(W/'test/array_frontier_order.graph').read_text();(D/'positive.graph').write_text(positive)
(D/'opaque.graph').write_text(positive.replace('hits[v]=hits[v]+1;','print v; hits[v]=hits[v]+1;'))
records=[]
for name in ['positive','opaque']:
 env=series.bench.clean_env('p1',32);env['FORCE_CPU']='1'
 series.cmdrun([str(W/'GraphProgram'),'--ir-backend=cpu','--emit-ir-to='+str(D/(name+'.ll')),str(D/(name+'.graph'))],D,D/(name+'.compile.log'),env=env)
 ir=(D/(name+'.ll')).read_text();calls=[x for x in ir.splitlines() if 'call ' in x and '@autograph_exec_op_create' in x]
 certified=any(re.search(r'@autograph_exec_op_create\(i64 513\b',x) for x in calls)
 assert certified==(name=='positive'),(name,certified,calls)
 shutil.copy2(D/'program.o',D/(name+'.o'));records.append({'fixture':name,'certificate_emitted':certified,'operation_calls':calls})
(P/'compiler_proof_checks.json').write_text(json.dumps(records,indent=2));print(json.dumps(records),flush=True)
