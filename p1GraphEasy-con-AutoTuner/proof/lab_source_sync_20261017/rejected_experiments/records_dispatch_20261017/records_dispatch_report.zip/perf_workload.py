import json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P));import series
spec=json.loads(Path(sys.argv[1]).read_text())
env=series.bench.clean_env(spec['framework'],32)
for i in range(5):subprocess.run(spec['command'],cwd=spec['cwd'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
