from pathlib import Path
import csv,json
P=Path(__file__).resolve().parent
rows=[]
for stage in ['01_segment_view','02_compact_parallel_view','03_view_dispatch_versioning']:
 for r in json.loads((P/stage/'results.json').read_text()):
  rows.append(dict(stage=stage,algorithm=r['algorithm'],graph=r['graph'],current_p1_ms=1000*r['means']['baseline'],candidate_p1_ms=1000*r['means']['candidate'],graptor_ms=1000*r['means']['graptor'],current_over_candidate=r['improvement'],median_current_over_candidate=r['median_improvement'],installed=False))
with (P/'regenerated_all_trials.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
