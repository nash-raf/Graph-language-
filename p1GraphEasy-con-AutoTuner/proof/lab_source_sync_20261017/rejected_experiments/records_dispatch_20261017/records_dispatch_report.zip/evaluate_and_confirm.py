from pathlib import Path
import time,subprocess,sys,json,math,statistics,shutil
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));import series
stages=['01_dispatch_cachelines','02_preparation_versioning','03_worker_budget_scope','04_preparation_team_fusion']
while not (P/stages[-1]/'decision.json').exists():time.sleep(3)
trials=[json.loads((P/s/'decision.json').read_text()) for s in stages]
eligible=[d for d in trials if d['accepted']]
result={'installed':False,'stages':trials,'selected':None,'acceptance_rule':'Require >1% mean and median geomean gain in both independent five-repeat blocks; reject any pooled per-case mean or median regression over 3%, or confirmed runtime regression. All source and timing samples retained.'}
if eligible:
 best=max(eligible,key=lambda d:math.log(d['geomean_improvement'])+math.log(d['geomean_median_improvement']))['stage'];name=best+'_confirmation';W=P/name;W.mkdir()
 for f in (P/best).iterdir():
  if f.is_file() and f.suffix in ['.c','.cpp','.h','.inc']:shutil.copy2(f,W/f.name)
 (W/'cases').symlink_to(P/best/'cases')
 decision=series.compare(name,record_decision=False)
 a=json.loads((P/best/'results.json').read_text());b=json.loads((W/'results.json').read_text());pooled=[]
 for x,y in zip(a,b):
  assert (x['algorithm'],x['graph'])==(y['algorithm'],y['graph'])
  samples={v:x['samples'][v]+y['samples'][v] for v in x['samples']}
  means={v:statistics.mean(t) for v,t in samples.items()};medians={v:statistics.median(t) for v,t in samples.items()}
  pooled.append({'algorithm':x['algorithm'],'graph':x['graph'],'samples':samples,'means':means,'medians':medians,'mean_improvement':means['baseline']/means['candidate'],'median_improvement':medians['baseline']/medians['candidate']})
 regressions=[r for r in pooled if r['mean_improvement']<.97 or r['median_improvement']<.97]
 result.update(selected=best,confirmation=decision,pooled=pooled,pooled_regressions=regressions,eligible_to_install=decision['accepted'] and not regressions)
else:result.update(eligible_to_install=False,reason='No candidate passed the independent primary mean-and-median performance gate.')
(P/'final_evaluation.json').write_text(json.dumps(result,indent=2));print('FINAL_EVALUATION',json.dumps({k:v for k,v in result.items() if k not in ['pooled','stages']}),flush=True)
subprocess.run([sys.executable,'-u',str(P/'profile_fusion.py')],cwd=P,check=True)
(P/'evaluation_complete.json').write_text(json.dumps({'complete':True,'eligible_to_install':result['eligible_to_install']}))
