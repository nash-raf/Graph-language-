from pathlib import Path
import json,subprocess,importlib.util,sys,os,statistics,math,time,shutil,csv,gc,difflib
import numpy as np
import resource
S=Path('/media/readinggroup/Storage/splash');P=S/'bench/optimizations/segment_view_20261017';A=S/'bench/optimizations/execution_compaction_20261016';R=S/'bench/e2e150'
spec=importlib.util.spec_from_file_location('bench',R/'run_benchmarks_201_273_r5.py');bench=importlib.util.module_from_spec(spec);spec.loader.exec_module(bench);bench.unlimited_stack();plan=json.loads((P/'benchmark_plan.json').read_text())['cases'];launcher=bench.Launcher(R)
def cmdrun(cmd,cwd,log,timeout=600,env=None):
 log.parent.mkdir(parents=True,exist_ok=True)
 with open(log,'w') as f:r=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout,preexec_fn=(lambda:resource.setrlimit(resource.RLIMIT_STACK,(8*1024*1024,resource.RLIM_INFINITY))) if cmd[:1]==['bash'] and len(cmd)>1 and cmd[1].startswith('test/') else None)
 if r.returncode:raise RuntimeError(str(cmd)+' failed; '+str(log))
def build(stage,regenerate=False):
 W=P/stage;(W/'logs').mkdir(exist_ok=True)
 cmdrun(['gcc','-O3','-fopenmp','-pthread','-c','autotuner_runtime.c','-o','autotuner_runtime.o'],W,W/'logs/runtime_build.log')
 for c in plan:
  alg=c['algorithm'];row=c['row'];old=bench.case_dir(A/'optimized',alg,row);d=bench.case_dir(W/'cases',alg,row);d.mkdir(parents=True,exist_ok=True)
  for f in W.glob('*.ll'):
   if not (d/f.name).exists():(d/f.name).symlink_to(f)
  for name in ['timed','validate']:
   if regenerate:
    env=bench.clean_env('p1',32);env['FORCE_CPU']='1';cmdrun([str(W/'GraphProgram'),'--ir-backend=cpu',str(old/(name+'.graph'))],d,d/(name+'.compile.log'),env=env);shutil.move(d/'program.o',d/(name+'.o'))
   elif not (d/(name+'.o')).exists():
    accepted=P/json.loads((P/'state.json').read_text())['accepted'];prior=bench.case_dir(accepted/'cases',alg,row)/(name+'.o');shutil.copy2(prior if prior.exists() else old/(name+'.o'),d/(name+'.o'))
   cmdrun(['g++','-O3','-fopenmp','-no-pie',str(d/(name+'.o'))]+[str(W/o) for o in bench.OBJECTS]+['-Wl,--wrap=timer_runtime','-ldl','-lnlopt','-o',str(d/name)],W,d/(name+'.link.log'))
 print('BUILT',stage,flush=True)
def tests(stage,names):
 W=P/stage
 for name in names:
  cmdrun(['bash','test/'+name],W,W/'logs'/name.replace('.sh','.log'));print('TEST_PASS',stage,name,flush=True)
def compare(stage,base_override=None,record_decision=True):
 state=json.loads((P/'state.json').read_text());base=base_override or state['accepted'];W=P/stage;directory=W/'comparison';directory.mkdir(exist_ok=True);results=[]
 def invoke(variant,c,phase,repeat):
  alg=c['algorithm'];row=c['row'];g=row['graph'];d=directory/(alg+'_'+g.replace('/','_'));d.mkdir(exist_ok=True);tag=variant+'_'+phase+'_'+str(repeat)
  if variant=='graptor':cmd,env,cwd=bench.command(R,W/'cases',alg,'graptor',row,32,phase=='validate')
  else:
   folder=bench.case_dir(P/(base if variant=='baseline' else stage)/'cases',alg,row);cmd=[str(folder/('validate' if phase=='validate' else 'timed'))];env=bench.clean_env('p1',32);cwd=folder
  if phase=='validate' and variant=='graptor':env['BENCH_OUTPUT']=str(d/(tag+'.values'))
  rec=launcher.run(cmd,cwd,env,d/(tag+'.log'),600,d/(tag+'.stamp'));assert rec['exit_code']==0 and not rec['timeout'],rec
  if phase=='validate':
   if variant=='graptor':v=np.loadtxt(d/(tag+'.values'),ndmin=1)
   else:
    text=Path(rec['log']).read_text();v=np.asarray(text.split('VALUES_BEGIN\n',1)[1].split('VALUES_END',1)[0].split(),dtype=np.float64)
   expected=bench.reference(alg,row,P/'references');rec['validation']=bench.validate_values(alg,'graptor' if variant=='graptor' else 'p1',row,v,expected);del v,expected;gc.collect()
  with (W/'measurements.jsonl').open('a') as f:f.write(json.dumps({'variant':variant,'algorithm':alg,'graph':g,'phase':phase,'repeat':repeat,**rec})+'\n')
  return rec
 for idx,c in enumerate(plan):
  (W/'status.json').write_text(json.dumps({'completed':idx,'total':len(plan),'algorithm':c['algorithm'],'graph':c['row']['graph'],'active':True}))
  for v in ['baseline','candidate','graptor']:invoke(v,c,'validate',0);invoke(v,c,'warmup',0)
  samples={v:[] for v in ['baseline','candidate','graptor']}
  for i in range(5):
   variants=['baseline','candidate','graptor'];variants=variants[i%len(variants):]+variants[:i%len(variants)]
   for v in variants:samples[v].append(invoke(v,c,'measure',i)['seconds'])
  means={v:statistics.mean(t) for v,t in samples.items()};medians={v:statistics.median(t) for v,t in samples.items()}
  rec={'algorithm':c['algorithm'],'graph':c['row']['graph'],'samples':samples,'means':means,'medians':medians,'improvement':means['baseline']/means['candidate'],'median_improvement':medians['baseline']/medians['candidate'],'graptor_over_candidate':means['graptor']/means['candidate'],'validated':True}
  results.append(rec);(W/'results.json').write_text(json.dumps(results,indent=2));print('CASE',stage,idx+1,len(plan),rec['algorithm'],rec['graph'],'improvement',round(rec['improvement'],3),'median',round(rec['median_improvement'],3),flush=True)
 # Confirm suspected regressions without dropping any original samples.
 regressions=[]
 for c,r in zip(plan,results):
  if r['median_improvement']<.95 or r['improvement']<.90:
   extra={v:[] for v in ['baseline','candidate']}
   for i in range(5):
    for v in (['baseline','candidate'] if i%2==0 else ['candidate','baseline']):extra[v].append(invoke(v,c,'confirm',i)['seconds'])
   r['confirmation']=extra;r['confirmation_mean_improvement']=statistics.mean(extra['baseline'])/statistics.mean(extra['candidate']);r['confirmation_median_improvement']=statistics.median(extra['baseline'])/statistics.median(extra['candidate'])
   if r['confirmation_mean_improvement']<.95 and r['confirmation_median_improvement']<.95:regressions.append({'algorithm':r['algorithm'],'graph':r['graph'],'ratio':r['confirmation_mean_improvement']})
 geo=lambda key:math.exp(statistics.mean(math.log(r[key]) for r in results));improvement=geo('improvement');median=geo('median_improvement')
 accepted=improvement>1.01 and median>1.01 and not regressions
 decision={'stage':stage,'baseline':base,'accepted':accepted,'geomean_improvement':improvement,'geomean_median_improvement':median,'confirmed_regressions':regressions,'rule':'Accept only if both mean- and median-based geomeans improve >1%, with no confirmed >5% per-case regression. Suspected regressions get five additional paired confirmation launches. All timings kept.','cases':len(results),'failed_cases':0,'missing_pairs':0,'p1_wins_vs_graptor':sum(r['graptor_over_candidate']>1 for r in results)}
 (W/'results.json').write_text(json.dumps(results,indent=2));(W/'decision.json').write_text(json.dumps(decision,indent=2));(W/'status.json').write_text(json.dumps({'active':False,'completed':len(results),'total':len(plan)}));state['completed'].append(decision)
 if accepted and record_decision:state['accepted']=stage
 if record_decision:(P/'state.json').write_text(json.dumps(state,indent=2))
 print('DECISION',json.dumps(decision),flush=True)
 # Auditable diff against the stage's actual baseline.
 diffs=[]
 for f in W.iterdir():
  if f.suffix in ['.c','.cpp','.h','.inc'] and (P/base/f.name).exists() and f.read_bytes()!=(P/base/f.name).read_bytes():diffs.extend(difflib.unified_diff((P/base/f.name).read_text().splitlines(True),f.read_text().splitlines(True),'a/'+f.name,'b/'+f.name))
 (W/'change.patch').write_text(''.join(diffs));return decision
if __name__=='__main__':
 stage=sys.argv[1];build(stage, '--regenerate' in sys.argv)
 if stage!='00_baseline':
  tests(stage,['run_array_append_epoch_tests.sh','run_array_frontier_lease_tests.sh','run_array_frontier_exec_tests.sh','run_empty_partition_effects_tests.sh'])
  compare(stage)

def clone(stage):
 base=P/json.loads((P/'state.json').read_text())['accepted'];W=P/stage;W.mkdir(exist_ok=True)
 for f in base.iterdir():
  if f.is_file() and (f.suffix in ['.c','.cpp','.h','.inc','.o','.ll','.sh'] or f.name=='GraphProgram'):shutil.copy2(f,W/f.name)
 for name in ['test','generated','build_lowmem']:shutil.copytree(base/name,W/name,dirs_exist_ok=True)
 (W/'logs').mkdir(exist_ok=True);return W
