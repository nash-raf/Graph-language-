
// Generated from Base.g4 by ANTLR 4.13.1

#pragma once


#include "antlr4-runtime.h"
#include "BaseVisitor.h"


/**
 * This class provides an empty implementation of BaseVisitor, which can be
 * extended to create a visitor which only needs to handle a subset of the available methods.
 */
class  BaseBaseVisitor : public BaseVisitor {
public:

  virtual std::any visitProgram(BaseParser::ProgramContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitStatement(BaseParser::StatementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitSwapStatement(BaseParser::SwapStatementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitWeightedGraphDef(BaseParser::WeightedGraphDefContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitUnweightedGraphDef(BaseParser::UnweightedGraphDefContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitPlainGraphDef(BaseParser::PlainGraphDefContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitLoadGraphDef(BaseParser::LoadGraphDefContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitGraphProperty(BaseParser::GraphPropertyContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitNodes(BaseParser::NodesContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitEdges(BaseParser::EdgesContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitNodeList(BaseParser::NodeListContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitEdgeList(BaseParser::EdgeListContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitGraphID(BaseParser::GraphIDContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitNodeID(BaseParser::NodeIDContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitFileEdgeList(BaseParser::FileEdgeListContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitEdge(BaseParser::EdgeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitSimpleDeclaration(BaseParser::SimpleDeclarationContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitArrayDeclaration(BaseParser::ArrayDeclarationContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitSetDecl(BaseParser::SetDeclContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitSetInitializer(BaseParser::SetInitializerContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitSetOperation(BaseParser::SetOperationContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitSetTarget(BaseParser::SetTargetContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitSetUnion(BaseParser::SetUnionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitGraphEdgesSet(BaseParser::GraphEdgesSetContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitSetIntersect(BaseParser::SetIntersectContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitSetId(BaseParser::SetIdContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitSetLiteral(BaseParser::SetLiteralContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitParenSet(BaseParser::ParenSetContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitGraphNodesSet(BaseParser::GraphNodesSetContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitSetAddMethod(BaseParser::SetAddMethodContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitSetRemoveMethod(BaseParser::SetRemoveMethodContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitConditionalStatement(BaseParser::ConditionalStatementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitExprCondition(BaseParser::ExprConditionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitNodeCheck(BaseParser::NodeCheckContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitHasEdgeCall(BaseParser::HasEdgeCallContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitLogicalAnd(BaseParser::LogicalAndContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitRelational(BaseParser::RelationalContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitEdgeCheck(BaseParser::EdgeCheckContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitHasNodeCheck(BaseParser::HasNodeCheckContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitHasNodeCall(BaseParser::HasNodeCallContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitHasEdgeCheck(BaseParser::HasEdgeCheckContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitLogicalOr(BaseParser::LogicalOrContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitGraphComprehension(BaseParser::GraphComprehensionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitGraphExpr(BaseParser::GraphExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitMotifMatchesDecl(BaseParser::MotifMatchesDeclContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitGraphListDecl(BaseParser::GraphListDeclContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitMotifSearchDecl(BaseParser::MotifSearchDeclContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitMotifEdge(BaseParser::MotifEdgeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitGraphLogicalAnd(BaseParser::GraphLogicalAndContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitDegreeCondition(BaseParser::DegreeConditionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitCycleCondition(BaseParser::CycleConditionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitConnectedCondition(BaseParser::ConnectedConditionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitMotifCondition(BaseParser::MotifConditionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitGraphLogicalOr(BaseParser::GraphLogicalOrContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitParenGraphCondition(BaseParser::ParenGraphConditionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitLoopStatement(BaseParser::LoopStatementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitForeachStatement(BaseParser::ForeachStatementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitForeachNodes(BaseParser::ForeachNodesContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitForeachEdges(BaseParser::ForeachEdgesContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitForeachNeighbors(BaseParser::ForeachNeighborsContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitForEachElement(BaseParser::ForEachElementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitForEachGraph(BaseParser::ForEachGraphContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitForEachMotif(BaseParser::ForEachMotifContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitForEachPlain(BaseParser::ForEachPlainContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitWhileStatement(BaseParser::WhileStatementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitGraphAddNodesCall(BaseParser::GraphAddNodesCallContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitGraphAddEdgesCall(BaseParser::GraphAddEdgesCallContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitGraphRemoveNodesCall(BaseParser::GraphRemoveNodesCallContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitGraphRemoveEdgesCall(BaseParser::GraphRemoveEdgesCallContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitQueryStatement(BaseParser::QueryStatementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitShowgraph(BaseParser::ShowgraphContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitFunction(BaseParser::FunctionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitReturnType(BaseParser::ReturnTypeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitParamList(BaseParser::ParamListContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitParam(BaseParser::ParamContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitType(BaseParser::TypeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitDrawgraph(BaseParser::DrawgraphContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitDrawmotifs(BaseParser::DrawmotifsContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitDrawMotifOption(BaseParser::DrawMotifOptionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitDrawOption(BaseParser::DrawOptionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitVertexDrawOption(BaseParser::VertexDrawOptionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitEdgeDrawOption(BaseParser::EdgeDrawOptionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitColorMapping(BaseParser::ColorMappingContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitContinuousMapping(BaseParser::ContinuousMappingContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitDrawBoolLiteral(BaseParser::DrawBoolLiteralContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitFunctionCall(BaseParser::FunctionCallContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitArgumentList(BaseParser::ArgumentListContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitSleepStatement(BaseParser::SleepStatementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitBlock(BaseParser::BlockContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitReturnStatement(BaseParser::ReturnStatementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitBreakStatement(BaseParser::BreakStatementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitContinueStatement(BaseParser::ContinueStatementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitPrintStatement(BaseParser::PrintStatementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitPrintExpr(BaseParser::PrintExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitPrintArrayStatement(BaseParser::PrintArrayStatementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitEdgePrint(BaseParser::EdgePrintContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitNodePrint(BaseParser::NodePrintContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitGraphPrint(BaseParser::GraphPrintContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitBoolTrueExpr(BaseParser::BoolTrueExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitTimerExpr(BaseParser::TimerExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitIdExpr(BaseParser::IdExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitBoolFalseExpr(BaseParser::BoolFalseExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitArrayAccessExpr(BaseParser::ArrayAccessExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitSetLitExpr(BaseParser::SetLitExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitSetSizeExpr(BaseParser::SetSizeExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitArray2DAccessExpr(BaseParser::Array2DAccessExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitArrayPrint(BaseParser::ArrayPrintContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitInfExpr(BaseParser::InfExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitFuncExpr(BaseParser::FuncExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitSetContainsExpr(BaseParser::SetContainsExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitMulDivExpr(BaseParser::MulDivExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitNotExpr(BaseParser::NotExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitIntExpr(BaseParser::IntExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitSetPopExpr(BaseParser::SetPopExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitParenExpr(BaseParser::ParenExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitRealExpr(BaseParser::RealExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitLogicalExpr(BaseParser::LogicalExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitAddSubExpr(BaseParser::AddSubExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitUnaryMinusExpr(BaseParser::UnaryMinusExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitSized2DArray(BaseParser::Sized2DArrayContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitSizedArray(BaseParser::SizedArrayContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitUnsizedArray(BaseParser::UnsizedArrayContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitArrayInitializer(BaseParser::ArrayInitializerContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitAssignmentStatement(BaseParser::AssignmentStatementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitArray2DAssignStmt(BaseParser::Array2DAssignStmtContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitArrayAssignStmt(BaseParser::ArrayAssignStmtContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitWeights(BaseParser::WeightsContext *ctx) override {
    return visitChildren(ctx);
  }


};

