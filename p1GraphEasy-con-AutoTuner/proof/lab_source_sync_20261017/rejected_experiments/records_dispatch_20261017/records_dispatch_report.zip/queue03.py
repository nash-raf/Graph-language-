from pathlib import Path
import time,subprocess,sys
P=Path(__file__).resolve().parent
while not (P/'02_preparation_versioning/decision.json').exists():time.sleep(3)
subprocess.run([sys.executable,'-u',str(P/'run03.py')],cwd=P,check=True)
