from pathlib import Path
import sys
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));import series
series.build('04_preparation_team_fusion')
series.tests('04_preparation_team_fusion',['run_array_preparation_exec_tests.sh','run_array_frontier_exec_tests.sh','run_array_frontier_lease_tests.sh','run_empty_partition_effects_tests.sh'])
series.compare('04_preparation_team_fusion',record_decision=False)
