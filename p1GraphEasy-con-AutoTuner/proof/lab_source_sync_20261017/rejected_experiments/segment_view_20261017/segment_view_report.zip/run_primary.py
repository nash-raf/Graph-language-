from pathlib import Path
import sys,json,re
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));import series
assert (P/'compiler_proof_checks.json').exists()
W=P/'01_segment_view';series.build('01_segment_view');activation=[]
for alg,needle in [('sssp','DSJC'),('sssp','slashdot'),('bfs','roadNet')]:
 c=next(c for c in series.plan if c['algorithm']==alg and needle in c['row']['graph']);d=series.bench.case_dir(W/'cases',alg,c['row']);env=series.bench.clean_env('p1',32);env['SGPL_SEGMENT_DEBUG']='1'
 log=W/(needle+'.activation.log');rec=series.launcher.run([str(d/'timed')],d,env,log,600,W/(needle+'.activation.stamp'));assert rec['exit_code']==0
 text=Path(rec['stderr_log']).read_text();counts=[tuple(map(int,x)) for x in re.findall(r'pairs=(\d+) descriptors=(\d+)',text)]
 if needle=='DSJC':assert counts,text
 activation.append({'algorithm':alg,'graph':c['row']['graph'],'descriptor_rounds':len(counts),'pairs':sum(a for a,b in counts),'descriptors':sum(b for a,b in counts),'builds':text.count('[segment-view] build')})
(P/'activation.json').write_text(json.dumps(activation,indent=2));print('ACTIVATION',json.dumps(activation),flush=True)
series.compare('01_segment_view',record_decision=False)
