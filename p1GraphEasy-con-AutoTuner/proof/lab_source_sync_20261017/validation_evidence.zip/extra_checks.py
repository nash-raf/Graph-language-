from pathlib import Path
import time,subprocess,json
root=Path(__file__).resolve().parent;src=root/'source'
while True:
 p=root/'validation.json'
 if p.exists() and json.loads(p.read_text()).get('complete'):break
 time.sleep(5)
results=[]
for name,cmd in [('iterator_phase_regressions',['python3','test/pdg_tdg_verification/test_autotuner_iterator_phases.py']),('autotuner_frequency_regressions',['python3','test/pdg_tdg_verification/test_autotuner_frequency.py','--frontend'])]:
 with (root/(name+'.log')).open('w') as log:
  p=subprocess.run(cmd,cwd=src,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
 results.append({'name':name,'exit_code':p.returncode});(root/'extra_validation.json').write_text(json.dumps({'complete':False,'results':results},indent=2))
(root/'extra_validation.json').write_text(json.dumps({'complete':True,'passed':all(x['exit_code']==0 for x in results),'results':results},indent=2))
