from pathlib import Path
import time,subprocess,sys
P=Path(__file__).resolve().parent
while not (P/'01_dispatch_cachelines/decision.json').exists():time.sleep(3)
subprocess.run([sys.executable,'-u',str(P/'run02.py')],cwd=P,check=True)
