from pathlib import Path
import sys
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));import series
series.build('03_worker_budget_scope')
series.tests('03_worker_budget_scope',['run_array_frontier_exec_tests.sh','run_empty_partition_effects_tests.sh','run_round_spatial_exec_tests.sh'])
series.compare('03_worker_budget_scope',record_decision=False)
